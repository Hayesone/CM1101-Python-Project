item_id = {
    "id": "id",
	
	"mass":	0.5,

    "name": "id card",

    "description":
    """You new shiny student ID card. Expires 1 June 2017.
You wonder why they have printed a suicide hotline number on it?..."""
}

item_laptop = {
    "id": "laptop",
	
	"mass":	5.0,

    "name": "laptop",

    "description":
    "It has seen better days. At least it has a WiFi card!"
}

item_money = {
    "id": "money",
	
	"mass": 2.0,

    "name": "money",

    "description":
    "This wad of cash is barely enough to pay your tuition fees."
}

item_biscuits = {
    "id": "biscuits",
	
	"mass": 1.0,

    "name": "a pack of biscuits",

    "description": "A pack of biscuits."
}

item_pen = {
    "id": "pen",
	
	"mass": 0.5,
    
    "name": "a pen",

    "description": "A basic ballpoint pen."
}

item_handbook = {
    "id": "handbook",
	
	"mass": 1.5,
    
    "name": "a student handbook",

    "description": "This student handbook explains everything. Seriously."
}


quick_ids = {
    "id": item_id,
    "laptop": item_laptop,
    "money": item_money,
    "biscuits": item_biscuits,
    "pen": item_pen,
    "handbook": item_handbook
} #creates a dictrionary for the item ids